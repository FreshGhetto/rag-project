# RAG con Mistral + Chroma (Docker)

Guida per avviare lo script `rag_mistral.py` con Mistral e un Chroma server Docker. Il DB vettoriale vive nel container `chroma` con volume persistente.

## Prerequisiti
- Docker e Docker Compose.
- File `.env` in questa cartella con:
  ```
  MISTRAL_API_KEY=il_tuo_token_mistral
  ```
- PDF sorgente `documento_esempio.pdf` in root (montato in sola lettura).

## Avvio con Docker Compose (interattivo)
1. Build:
   ```sh
   docker compose build
   ```
2. Avvia Chroma in background:
   ```sh
   docker compose up -d chroma
   ```
3. Esegui l’app in modo interattivo (stdin abilitato):
   ```sh
   docker compose run --rm -it rag
   ```
   Vedrai il conteggio dei chunk e il prompt “Domanda:”. Invio vuoto per uscire.

## Avvio con Docker CLI (senza compose)
1. Avvia Chroma:
   ```sh
   docker run -d --name chroma -p 8000:8000 -v chroma-data:/chroma/.chroma/index chromadb/chroma:0.5.7
   ```
2. Build immagine app:
   ```sh
   docker build -t rag-mistral .
   ```
3. Esegui l’app puntando al servizio Chroma (interattivo):
   ```sh
   docker run -it --rm --env-file .env -e CHROMA_HOST=host.docker.internal -e CHROMA_PORT=8000 -v "%cd%/documento_esempio.pdf:/app/documento_esempio.pdf:ro" rag-mistral
   ```
   Su shell POSIX usa `$(pwd)` al posto di `%cd%`.

## Note utili
- La chiave Mistral è letta da `MISTRAL_API_KEY`; l’app fallisce con messaggio chiaro se manca.
- Il numero di chunk creati viene stampato a video all’avvio (es. “Creati N chunk ...”).
- Modalità non interattiva: puoi impostare `QUESTION="la tua domanda"` nell’ambiente per eseguire una sola query e uscire.
- Per usare un PDF diverso, monta il file su `/app/documento_esempio.pdf` o modifica `pdf_path` nello script e aggiorna il volume.
- Il volume `chroma-data` mantiene l’indice tra i riavvii del container Chroma.
