import os

# Import dei componenti RAG
from langchain_community.document_loaders import PyPDFLoader
from langchain_experimental.text_splitter import SemanticChunker
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_mistralai import ChatMistralAI
from langchain_community.vectorstores import Chroma
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate
import chromadb


def setup_rag():
    print("--- 1. Caricamento Documento ---")
    pdf_path = "documento_esempio.pdf"
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"PDF non trovato: {pdf_path}")
    loader = PyPDFLoader(pdf_path)
    docs = loader.load()

    print("--- 2. Inizializzazione Embedding Semantici ---")
    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    print("--- 3. Semantic Chunking (Analisi concetti) ---")
    text_splitter = SemanticChunker(
        embeddings,
        breakpoint_threshold_type="percentile",
    )
    chunks = text_splitter.split_documents(docs)
    chunk_count = len(chunks)
    print(f"Creati {chunk_count} chunk che mantengono la continuita semantica.")

    print("--- 4. Connessione a Chroma (vector DB) ---")
    chroma_host = os.getenv("CHROMA_HOST", "localhost")
    chroma_port = int(os.getenv("CHROMA_PORT", "8000"))
    chroma_client = chromadb.HttpClient(host=chroma_host, port=chroma_port)

    collection_name = "rag_docs"
    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        client=chroma_client,
        collection_name=collection_name,
    )
    retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

    print("--- 5. Collegamento a Mistral API ---")
    api_key = os.getenv("MISTRAL_API_KEY")
    if not api_key:
        raise ValueError(
            "ERRORE: variabile MISTRAL_API_KEY mancante. "
            'Impostala nell\'ambiente (es. $env:MISTRAL_API_KEY="chiave").'
        )

    llm = ChatMistralAI(api_key=api_key, model="open-mistral-7b")

    prompt = ChatPromptTemplate.from_template(
        "Usa solo il contesto fornito per rispondere alla domanda.\n"
        "Contesto: {context}\n"
        "Domanda: {input}\n"
        "Risposta:"
    )

    combine_docs_chain = create_stuff_documents_chain(llm, prompt)
    return create_retrieval_chain(retriever, combine_docs_chain)


if __name__ == "__main__":
    try:
        rag_system = setup_rag()
        preset_question = os.getenv("QUESTION")
        if preset_question:
            print("\n--- Esecuzione non interattiva (variabile QUESTION presente) ---")
            response = rag_system.invoke({"input": preset_question})
            print(f"\nDomanda: {preset_question}\nMistral:\n{response['answer']}")
        else:
            print("\n--- Sistema Pronto! Fai la tua domanda (invio vuoto per uscire) ---")
            while True:
                try:
                    query = input("\nDomanda: ").strip()
                except EOFError:
                    print("\nInput non disponibile, chiusura.")
                    break
                if not query:
                    print("Chiusura.")
                    break
                response = rag_system.invoke({"input": query})
                print(f"\nMistral:\n{response['answer']}")
    except Exception as e:
        print(f"\n[ERRORE]: {e}")
